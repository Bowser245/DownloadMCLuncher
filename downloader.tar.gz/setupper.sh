#!/bin/bash

# Étape 1 : Récupérer le dossier actuel où se trouve le script .sh
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

echo "Configuration de l'environnement dans : $DIR"

# Étape 2 : Création de l'environnement virtuel (nommé 'env')
if [ ! -d "env" ]; then
    echo "Creation de l'environnement virtuel Python..."
    python3 -m venv env
else
    echo "L'environnement virtuel existe deja."
fi

# Étape 3 : Source (activation) de l'environnement virtuel pour la session actuelle
echo "Activation de l'environnement virtuel..."
source env/bin/activate

# Étape 4 : Téléchargement du script Python (via l'URL raw)
PYTHON_SCRIPT_URL="https://raw.githubusercontent.com/Bowser245/downloadfile/main/startup.py"
SCRIPT_NAME="startup.py"

echo "Telechargement de $SCRIPT_NAME..."
curl -s -O "$PYTHON_SCRIPT_URL"

# On s'assure que le fichier a bien été téléchargé
if [ -f "$SCRIPT_NAME" ]; then
    echo "Telechargement reussi."
    pip install minecraft_launcher_lib
    
    RUN_SCRIPT="run.sh"
    echo "Creation du script de lancement rapide : $RUN_SCRIPT"
    
    echo "#!/bin/bash" > "$RUN_SCRIPT"
    echo "DIR=\"\$( cd \"\$( dirname \"\${BASH_SOURCE[0]}\" )\" && pwd )\"" >> "$RUN_SCRIPT"
    echo "cd \"\$DIR\"" >> "$RUN_SCRIPT"
    echo "source env/bin/activate" >> "$RUN_SCRIPT"
    echo "python3 startup.py" >> "$RUN_SCRIPT"
    
    # Application du chmod +x sur le nouveau script run.sh
    chmod +x "$RUN_SCRIPT"
    echo "Le fichier $RUN_SCRIPT a ete cree et rendu executable."

    # Étape 7 : Première exécution automatique du script Python
    echo "Execution initiale de $SCRIPT_NAME..."
    python "$SCRIPT_NAME"
else
    echo "Erreur lors du telechargement du script."
fi